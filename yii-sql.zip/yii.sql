/*
Navicat MySQL Data Transfer

Source Server         : conn
Source Server Version : 50160
Source Host           : localhost:3306
Source Database       : yii

Target Server Type    : MYSQL
Target Server Version : 50160
File Encoding         : 65001

Date: 2015-12-10 11:27:30
*/

SET FOREIGN_KEY_CHECKS=0;
